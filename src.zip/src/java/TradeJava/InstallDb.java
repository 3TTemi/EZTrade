package TradeJava;


public class InstallDb
{
  public static void main(String[] args)
  {
    // intialize datbase 
    String dbName = "UserCredentials";
    JavaDatabase dbObject = new JavaDatabase();
    // creata datbase and table    
//    dbObject.createDb(dbName);
//    String newTable = "CREATE TABLE UserInfo (username varchar(50) PRIMARY KEY, password varchar(50))";
//    String newTable = "CREATE TABLE UserBalance (username varchar(50), ezcoins double)";
   String newTable = "CREATE TABLE CoinInfo (name varchar(50) PRIMARY KEY, currentPrice double, marketCap double, circulatingSupply double)"; 
//   String newTable = "CREATE TABLE UserData (Username varchar(50), UserInputs varchar(50), AnswerOutput int)"; 
    dbObject.createTable(newTable, dbName);
  }
}
