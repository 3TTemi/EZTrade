package TradeJava;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author temiadebowale
 */
@WebServlet(urlPatterns =
{
   "/TradeEZcoin",
   "/CoinSelection",
   "/TradeCrpto"

})
public class Transactions extends HttpServlet
{

   /**
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    *
    * @param request servlet request
    * @param response servlet response
    * @throws ServletException if a servlet-specific error occurs
    * @throws IOException if an I/O error occurs
    */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException
   {
      response.setContentType("text/html;charset=UTF-8");
      try (PrintWriter out = response.getWriter())
      {
         /* TODO output your page here. You may use following sample code. */
         out.println("<!DOCTYPE html>");
         out.println("<html>");
         out.println("<head>");
         out.println("<title>Servlet Transactions</title>");
         out.println("</head>");
         out.println("<body>");
         out.println("<h1>Servlet Transactions at " + request.getContextPath() + "</h1>");
         out.println("</body>");
         out.println("</html>");
      }
   }

   // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
   /**
    * Handles the HTTP <code>GET</code> method.
    *
    * @param request servlet request
    * @param response servlet response
    * @throws ServletException if a servlet-specific error occurs
    * @throws IOException if an I/O error occurs
    */
   @Override
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException
   {
      processRequest(request, response);
   }

   /**
    * Handles the HTTP <code>POST</code> method.
    *
    * @param request servlet request
    * @param response servlet response
    * @throws ServletException if a servlet-specific error occurs
    * @throws IOException if an I/O error occurs
    */
   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException
   {
      String dbName = "UserCredentials";
      JavaDatabase dbObj = new JavaDatabase(dbName);
      Connection myDbConn = dbObj.getDbConn();

      HttpSession session = request.getSession();
      String userPath = request.getServletPath();

      if (userPath.equals("/TradeCrpto"))
      {
         String action = request.getParameter("action");

         if ("Buy".equals(action))
         {
            double amountCoin = Double.parseDouble(request.getParameter("cryptoAmount"));
            String username = (String) session.getAttribute("currentUserName");
            String coinName = ((String) session.getAttribute("coinTitle")).toLowerCase();

            double prevCoins = 0;
            double setCoins = 0;
            double circSupply = 0;
            double newcircSupply = 0;
            double amountCoinBought = 0;
            double currentCoinPrice = 0;
            double newPrice = 0;
            double finalPrice = 0;
            double currentMarketCap = 0;
            double waitMarketCap = 0;
            double newMarketCap = 0;
            double currentEZCoin = 0;
            double newEZCoin = 0;

            DecimalFormat df = new DecimalFormat("#.####");
            df.setRoundingMode(RoundingMode.CEILING);

            DecimalFormat ef = new DecimalFormat("0.0000E0");
            ef.setRoundingMode(RoundingMode.CEILING);

            //get current number of ez coins
            try
            {
               String dbQuery = "SELECT ezcoins FROM UserBalance WHERE username = " + "'" + username + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  currentEZCoin = Double.parseDouble(rsSelectCoin.getString(1));
               }

            }
            catch (Exception e)
            {
               System.out.println("Error in getting coin number");
            }
            if (amountCoin <= currentEZCoin)
            {
               
            // update number of ez coins 
            try
            {
               if (amountCoin <= currentEZCoin)
               {
                  newEZCoin = currentEZCoin - amountCoin;
                  String dbQuery = "UPDATE UserBalance SET ezcoins = ? WHERE username = ?";

                  PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
                  ps.setDouble(1, newEZCoin);
                  ps.setString(2, username);

                  ps.executeUpdate();
               }
               else
               {
                  response.sendRedirect("CoinPage.jsp");
                  System.out.println("Error at 9");
               }

//               newEZCoin = currentCoinPrice - amountCoin;
//               String dbQuery = "UPDATE UserBalance SET " + coinName + " = ? WHERE username = ?";
//               PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
//               ps.setDouble(1, setCoins);
//               ps.setString(2, username);
//
//               ps.executeUpdate();
//               response.sendRedirect("CoinPage.jsp");
            }
            catch (Exception e)
            {
            }

            // get number of current coins
            try
            {
               String dbQuery = "SELECT " + coinName + " FROM UserBalance WHERE username = " + "'" + username + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  prevCoins = Double.parseDouble(rsSelectCoin.getString(1));
               }

               dbQuery = "SELECT currentPrice FROM CoinInfo WHERE name = " + "'" + coinName + "'";
               psSelectCoins = myDbConn.prepareStatement(dbQuery);
               rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  currentCoinPrice = Double.parseDouble(rsSelectCoin.getString(1));
               }
            }
            catch (Exception e)
            {
            }

            // get current coin and add to amount wated 
            try
            {
               amountCoinBought = amountCoin / currentCoinPrice;

               setCoins = prevCoins + amountCoinBought;
               String dbQuery = "UPDATE UserBalance SET " + coinName + " = ? WHERE username = ?";
               PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, setCoins);
               ps.setString(2, username);

               ps.executeUpdate();
               response.sendRedirect("CoinPage.jsp");

            }
            catch (Exception e)
            {
            }

            // update circulating supply 
            try
            {

               String dbQuery = "SELECT circulatingSupply FROM CoinInfo WHERE name = " + "'" + coinName + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  circSupply = Double.parseDouble(rsSelectCoin.getString(1));
               }

               newcircSupply = Double.parseDouble(df.format(circSupply + amountCoinBought));

               dbQuery = "UPDATE CoinInfo SET circulatingSupply = ? WHERE name = ?";
               PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, newcircSupply);
               ps.setString(2, coinName);

               ps.executeUpdate();
//               response.sendRedirect("CoinPage.jsp");

               newPrice = ((amountCoinBought / circSupply) * currentCoinPrice) + currentCoinPrice;
               finalPrice = Double.parseDouble(df.format(newPrice));

               dbQuery = "UPDATE CoinInfo SET currentPrice = ? WHERE name = ?";
               ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, finalPrice);
               ps.setString(2, coinName);

               ps.executeUpdate();

               dbQuery = "SELECT marketCap FROM CoinInfo WHERE name = " + "'" + coinName + "'";
               psSelectCoins = myDbConn.prepareStatement(dbQuery);
               rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  currentMarketCap = Double.parseDouble(rsSelectCoin.getString(1));
               }

               waitMarketCap = newcircSupply * finalPrice;
               newMarketCap = Double.parseDouble(ef.format(waitMarketCap));

               System.out.println(newMarketCap);

               dbQuery = "UPDATE CoinInfo SET marketCap = ? WHERE name = ?";
               ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, newMarketCap);
               ps.setString(2, coinName);

               ps.executeUpdate();

            }
            catch (Exception e)
            {
            }
         }
            else
            {
               response.sendRedirect("BalanceError.jsp");
            }

         }

         if ("Sell".equals(action))
         {
           double amountCoin = Double.parseDouble(request.getParameter("cryptoAmount"));
            String username = (String) session.getAttribute("currentUserName");
            String coinName = ((String) session.getAttribute("coinTitle")).toLowerCase();

            double prevCoins = 0;
            double setCoins = 0;
            double circSupply = 0;
            double newcircSupply = 0;
            double amountCoinSell = 0;
            double currentCoinPrice = 0;
            double newPrice = 0;
            double finalPrice = 0;
            double currentMarketCap = 0;
            double waitMarketCap = 0;
            double newMarketCap = 0;
            double currentEZCoin = 0;
            double newEZCoin = 0;
            double prevamountinezcoin = 0;
            double newsetcrypto = 0;

            DecimalFormat df = new DecimalFormat("#.####");
            df.setRoundingMode(RoundingMode.CEILING);

            DecimalFormat ef = new DecimalFormat("0.0000E0");
            ef.setRoundingMode(RoundingMode.CEILING);
            // get number of crypto coins and get current price, then calculate total amount of ezcoiins tryna sell
            System.out.println("hi 1");
            try
            {
               String dbQuery = "SELECT " + coinName + " FROM UserBalance WHERE username = " + "'" + username + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  // previous number of crypto
                  prevCoins = Double.parseDouble(rsSelectCoin.getString(1));
               }

               dbQuery = "SELECT currentPrice FROM CoinInfo WHERE name = " + "'" + coinName + "'";
               psSelectCoins = myDbConn.prepareStatement(dbQuery);
               rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  // current crypto price 
                  currentCoinPrice = Double.parseDouble(rsSelectCoin.getString(1));
               }
               
               // In datbase of crypto coins converted to ezcoins 
               prevamountinezcoin = currentCoinPrice * prevCoins;
                           System.out.println("hi 2");

            }
            catch (Exception e)
            {
                              System.out.println("Something went wrong 1");

            }
            
            if (amountCoin <= prevamountinezcoin)
               {
                      
            // get current number of ezcoins
             try
            {
               String dbQuery = "SELECT ezcoins FROM UserBalance WHERE username = " + "'" + username + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  currentEZCoin = Double.parseDouble(rsSelectCoin.getString(1));
               }

            }
            catch (Exception e)
            {
               System.out.println("Error in getting coin number");
            }
            // update number of ezcoins 
             try
            {
               // amount im trying to sell has to be less than the prev amount in ezcoin 
//               if (amountCoin <= prevamountinezcoin)
//               {
                  newEZCoin = currentEZCoin + amountCoin;
                  String dbQuery = "UPDATE UserBalance SET ezcoins = ? WHERE username = ?";

                  PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
                  ps.setDouble(1, newEZCoin);
                  ps.setString(2, username);

                  ps.executeUpdate();
//               }
//               else
//               {
//                  response.sendRedirect("BalanceError.jsp");
//                  System.out.println("Something went wrong 3");
//                  
//                  
//
//               }
            System.out.println("hi 3ß");

            }
            catch (Exception e)
            {
                              System.out.println("Something went wrong 2");

            }
            
             // update the number of crypto coins 
            
            // prevcoins - the amount of coins you are trying to buy
            try
            {
//               if (amountCoin <= prevamountinezcoin)
//               {
                  amountCoinSell = amountCoin / currentCoinPrice;
                  newsetcrypto = prevCoins - amountCoinSell; 
               
                  String dbQuery = "UPDATE UserBalance SET " + coinName + " = ? WHERE username = ?";

                  PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
                  ps.setDouble(1, newsetcrypto);
                  ps.setString(2, username);

                  ps.executeUpdate();
//               }
//               else
//               {
//                                 System.out.println("Something went wrong 4");
//                  response.sendRedirect("BalanceError.jsp");
//                  
//               }
            }
            catch (Exception e)
              {
                                System.out.println("Something went wrong 5");
                                e.printStackTrace();

                 
              }
            
            
             // update circulating supply 
            try
            {

               String dbQuery = "SELECT circulatingSupply FROM CoinInfo WHERE name = " + "'" + coinName + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  circSupply = Double.parseDouble(rsSelectCoin.getString(1));
               }

               newcircSupply = Double.parseDouble(df.format(circSupply - amountCoinSell));

               dbQuery = "UPDATE CoinInfo SET circulatingSupply = ? WHERE name = ?";
               PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, newcircSupply);
               ps.setString(2, coinName);

               ps.executeUpdate();
//               response.sendRedirect("CoinPage.jsp");

               newPrice = currentCoinPrice - ((amountCoinSell / circSupply) * currentCoinPrice);
               finalPrice = Double.parseDouble(df.format(newPrice));

               dbQuery = "UPDATE CoinInfo SET currentPrice = ? WHERE name = ?";
               ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, finalPrice);
               ps.setString(2, coinName);

               ps.executeUpdate();

               dbQuery = "SELECT marketCap FROM CoinInfo WHERE name = " + "'" + coinName + "'";
               psSelectCoins = myDbConn.prepareStatement(dbQuery);
               rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  currentMarketCap = Double.parseDouble(rsSelectCoin.getString(1));
               }

               waitMarketCap = newcircSupply * finalPrice;
               newMarketCap = Double.parseDouble(ef.format(waitMarketCap));

               System.out.println(newMarketCap);

               dbQuery = "UPDATE CoinInfo SET marketCap = ? WHERE name = ?";
               ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, newMarketCap);
               ps.setString(2, coinName);

               ps.executeUpdate();
            System.out.println("hi 4");

            }
            catch (Exception e)
            {
                              System.out.println("Something went wrong 6");

            }
 
               }
            else
            {
               response.sendRedirect("BalanceError.jsp");
               System.out.println("Something went wrong 7");
            }
            
            response.sendRedirect("CoinPage.jsp");
         }
      }

      if (userPath.equals("/CoinSelection"))
      {
         String action = request.getParameter("coinaction");
         String title = "";
         String imageLink = "";
         String width = "";
         String height = "";

         if ("botcoin".equals(action))
         {
            title = "Botcoin";
            imageLink = "Images/bit.png";
            width = "150px";
            height = "150px";
         }
         if ("lethereum".equals(action))
         {
            title = "Lethereum";
            imageLink = "Images/eth.png";
            width = "120px";
            height = "213.4px";

         }
         if ("salano".equals(action))
         {
            title = "Salano";
            imageLink = "Images/sol.png";
            width = "150px";
            height = "150px";
         }

         session.setAttribute("coinTitle", title);
         session.setAttribute("coinImage", imageLink);
         session.setAttribute("coinWidth", width);
         session.setAttribute("coinHeight", height);

         response.sendRedirect("CoinPage.jsp");

      }

      if (userPath.equals("/TradeEZcoin"))
      {
         String action = request.getParameter("action");
         if ("Buy".equals(action))
         {
            double amountCoin = Double.parseDouble(request.getParameter("amounttext"));
            String username = (String) session.getAttribute("currentUserName");
            double prevCoins = 0;
            double setCoins = 0;

            try
            {
               String dbQuery = "SELECT ezcoins FROM UserBalance WHERE username = " + "'" + username + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  prevCoins = Double.parseDouble(rsSelectCoin.getString(1));
               }

            }
            catch (Exception e)
            {
            }

            try
            {
               setCoins = prevCoins + amountCoin;
               String dbQuery = "UPDATE UserBalance SET ezcoins = ? WHERE username = ?";
               PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
               ps.setDouble(1, setCoins);
               ps.setString(2, username);

               ps.executeUpdate();
               response.sendRedirect("HomePage.jsp");

            }
            catch (Exception e)
            {
            }

            session.setAttribute("currentEZcoins", setCoins);

         }
         if ("Sell".equals(action))
         {
            double amountCoin = Double.parseDouble(request.getParameter("amounttext"));
            String username = (String) session.getAttribute("currentUserName");
            double prevCoins = 0;
            double setCoins = 0;

            try
            {
               String dbQuery = "SELECT ezcoins FROM UserBalance WHERE username = " + "'" + username + "'";
               PreparedStatement psSelectCoins = myDbConn.prepareStatement(dbQuery);
               ResultSet rsSelectCoin = psSelectCoins.executeQuery();

               if (rsSelectCoin.next())
               {
                  prevCoins = Double.parseDouble(rsSelectCoin.getString(1));
               }

            }
            catch (Exception e)
            {
               System.out.println("Error at 1");
            }

            try
            {
               if (prevCoins >= amountCoin)
               {
                  setCoins = prevCoins - amountCoin;
                  String dbQuery = "UPDATE UserBalance SET ezcoins = ? WHERE username = ?";
                  PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
                  ps.setDouble(1, setCoins);
                  ps.setString(2, username);

                  ps.executeUpdate();
                  response.sendRedirect("HomePage.jsp");
               }
               else
               {
                  session.setAttribute("enoughError", "Not Enough EZCoins to sell");
                  response.sendRedirect("HomePage.jsp");
                  System.out.println("Error at 10");

               }
            }
            catch (Exception e)
            {
               System.out.println("Error at 2");

            }
            session.setAttribute("currentEZcoins", setCoins);

         }
      }

   }

   @Override
   public String getServletInfo()
   {
      return "Short description";
   }// </editor-fold>

}
