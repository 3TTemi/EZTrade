package TradeJava;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import  java.sql.PreparedStatement;

public class JavaDatabase
{

  // atributes name, connection, data
  private String dbName;
  private Connection dbConn;
  private ArrayList<ArrayList<String>> data;
  // consturctor without knowing name

  public JavaDatabase()
  {
    dbName = "";
    dbConn = null;
    data = null;
  }

  // consturctor with knowing nmae 
  public JavaDatabase(String dbName)
  {
    setDbName(dbName);
    setDbConn();
    data = null;
  }

  public String getDbName()
  {
    return dbName;
  }

  public void setDbName(String dbName)
  {
    this.dbName = dbName;
  }

  public Connection getDbConn()
  {
    return dbConn;
  }

  public void setDbConn()
  {
    String connectionURL = "jdbc:mysql://localhost:3306/" + this.dbName;
    this.dbConn = null;
    try
    {
      Class.forName("com.mysql.jdbc.Driver");
      this.dbConn = DriverManager.getConnection(connectionURL, "root", "mysql1");
    }
    catch (ClassNotFoundException ex)
    {
      System.out.println("Driver not found, check library");
    }
    catch (SQLException err)
    {
      System.out.println("SQL Connection error!");
      err.printStackTrace();
    }
  }

  public ArrayList<ArrayList<String>> getData(String tableName, String[] tableHeaders)
  {

    int columnCount = tableHeaders.length; // number of columns
    Statement s = null; // blank statemnet for SQL
    ResultSet rs = null; // pointer to data
    String dbQuery = "SELECT * FROM " + tableName; // to read the data
    this.data = new ArrayList<>(); // construct new data
    // read the data
    try
    {
      // send the query and recieve data
      s = this.dbConn.createStatement();
      rs = s.executeQuery(dbQuery);
      // read the data using rs and store in ArrayList data
      while (rs.next())
      {
        // row object to hold one row data
        ArrayList<String> row = new ArrayList<>();
        // go through the row and read each cell
        for (int i = 0; i < columnCount; i++)
        {
          // read cell i
          // example: String cell - rs.getString("Name");
          // reads the cell in column Name
          // tableHeaders = {"Name", "Age", "Color"}
          String cell = rs.getString(tableHeaders[i]);
          // add the cell to the row
          // example: row.add("Vinny");
          row.add(cell);
        }
        // add the row to the data
        //example: data.add "Vinny",15"Pink"
        this.data.add(row);
      }

    }
    catch (SQLException e)
    {
      System.out.println("SQL Error: Not able to get data");

    }
    return data;
  }
  
  
  public ArrayList<ArrayList<String>> getDataName(String tableName, String[] tableHeaders, String userName)
  {

    int columnCount = tableHeaders.length; // number of columns
    Statement s = null; // blank statemnet for SQL
    ResultSet rs = null; // pointer to data
    String dbQuery = "SELECT * FROM " + tableName + " WHERE Username =" + "'" +userName + "'"; // to read the data
    this.data = new ArrayList<>(); // construct new data
    // read the data
    try
    {
      // send the query and recieve data
      s = this.dbConn.createStatement();
      rs = s.executeQuery(dbQuery);
      // read the data using rs and store in ArrayList data
      while (rs.next())
      {
        // row object to hold one row data
        ArrayList<String> row = new ArrayList<>();
        // go through the row and read each cell
        for (int i = 0; i < columnCount; i++)
        {
          // read cell i
          // example: String cell - rs.getString("Name");
          // reads the cell in column Name
          // tableHeaders = {"Name", "Age", "Color"}
          String cell = rs.getString(tableHeaders[i]);
          // add the cell to the row
          // example: row.add("Vinny");
          row.add(cell);
        }
        // add the row to the data
        //example: data.add "Vinny",15"Pink"
        this.data.add(row);
      }

    }
    catch (SQLException e)
    {
      System.out.println("SQL Error: Not able to get data");

    }
    return data;
  }

  
  
  public void setData(ArrayList<ArrayList<String>> data)
  {
    this.data = data;
  }

  public void createDb(String newDbName)
  {
    this.dbName = newDbName;
    Connection newConn;
    String connectionURL = "jdbc:mysql://localhost:3306/";
    String query = "CREATE DATABASE " + this.dbName;
    try
    {
      Class.forName("com.mysql.jdbc.Driver");
      newConn = DriverManager.getConnection(connectionURL, "root", "mysql1");
      Statement s = newConn.createStatement();
      s.executeUpdate(query);
      System.out.println("New datbase created.");
      newConn.close();
    }
    catch (ClassNotFoundException ex)
    {
      System.out.println("Error creating database: " + newDbName);
    }
    catch (SQLException se)
    {
      System.out.println("SQL Connection error, Db was not created!");
    }

  }

  public void createTable(String newTable, String dbName)
  {
    System.out.println(newTable);
    setDbName(dbName);
    setDbConn();
    Statement s;
    try
    {
      s = this.dbConn.createStatement();
      s.execute(newTable);
      System.out.println("New table created.");
      this.dbConn.close();
    }
    catch (SQLException err)
    {
      System.out.println("Error creating table" + newTable);
    }

  }
  public void closeDbConn()
  {
    try
    {
      this.dbConn.close();
    }
    catch (Exception err)
    {
      System.out.println("DB closing error.");
    }
  }
  public Object[][] to2dArray(ArrayList<ArrayList<String>> data)
  {
    if (data.size() == 0)
    {
      Object[][] dataList = new Object[0][0];
      return dataList;
    }
    else
    {
      int columnCount = data.get(0).size();
      Object[][] dataList = new Object[data.size()][columnCount];
      for (int i = 0; i < data.size(); i++)
      {
        ArrayList<String> row = data.get(i);
        for (int j = 0; j < columnCount; j++)
        {
          dataList[i][j] = row.get(j);
        }
      }
      return dataList;
    }
  }

  
  public static void main(String[] args)
  {
    // db info 
    String dbName = "TestServletDB";
    String tableName = "Cars";
    String[] columnNames =
    {
      "name", "price", "color"
    };
    // insert query
    String dbQuery = "INSERT INTO Cars VALUES (?,?,?)";
    // connect to db
    JavaDatabase objDb = new JavaDatabase(dbName);
    Connection myDbConn = objDb.getDbConn();
    
    // read the data 
    String readName = "BMW";
    int readPrice = 25000;
    String readColor = "Orange";
    
    // insert into Database
//    try
//    {
//      PreparedStatement ps = myDbConn.prepareStatement(dbQuery);
//      ps.setString(1, readName);
//      ps.setInt(2, readPrice);
//      ps.setString(3, readColor);
//      ps.executeUpdate();
//      System.out.println("Data inserted successfully");
//    }
//    catch (Exception e)
//    {
//      System.out.println("Error inserting data");
//    }
    ArrayList<ArrayList<String>> data= objDb.getData(tableName, columnNames);
    System.out.println(data);
      
  }
  
//  public boolean addUser(userRep user)
//  {
//     dbName ="Credentials";
//     JavaDatabase dbObj = new JavaDatabase(dbName);
//     dbConn = dbObj.getDbConn();
//          
//     boolean set = false; 
//     
//     try
//     {
//        String dbQuery = "INSERT INTO Users VALUES (?,?)";
//        PreparedStatement ps = dbConn.prepareStatement(dbQuery);
//        ps.setString(1, user.getUserName());
//        ps.setString(2, user.getPassword());
//        
//        ps.executeUpdate();
//        set = true; 
//        
//     }
//     catch (Exception e)
//     {
//        e.printStackTrace();
//     }
//     
//     return set;
//  }

}
